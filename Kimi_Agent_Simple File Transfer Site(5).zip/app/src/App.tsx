import { useState, useCallback } from 'react'
import { Upload, File, X, Copy, Check, Download, Share2, Smartphone, Laptop, Tablet } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { toast } from 'sonner'
import './App.css'

interface SharedFile {
  id: string
  name: string
  size: number
  type: string
  data: string
  uploadedAt: Date
}

function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

function generateId(): string {
  return Math.random().toString(36).substring(2, 10).toUpperCase()
}

function App() {
  const [files, setFiles] = useState<SharedFile[]>([])
  const [uploadProgress, setUploadProgress] = useState<number>(0)
  const [isUploading, setIsUploading] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const [shareCode, setShareCode] = useState('')
  const [isDragging, setIsDragging] = useState(false)

  const handleFileUpload = useCallback((uploadedFiles: FileList | null) => {
    if (!uploadedFiles || uploadedFiles.length === 0) return

    setIsUploading(true)
    setUploadProgress(0)

    const file = uploadedFiles[0]
    const reader = new FileReader()

    reader.onprogress = (e) => {
      if (e.lengthComputable) {
        setUploadProgress((e.loaded / e.total) * 100)
      }
    }

    reader.onload = (e) => {
      const newFile: SharedFile = {
        id: generateId(),
        name: file.name,
        size: file.size,
        type: file.type,
        data: e.target?.result as string,
        uploadedAt: new Date()
      }

      const savedFiles = JSON.parse(localStorage.getItem('sharedFiles') || '[]')
      savedFiles.push(newFile)
      localStorage.setItem('sharedFiles', JSON.stringify(savedFiles))

      setFiles(prev => [...prev, newFile])
      setIsUploading(false)
      setUploadProgress(100)
      toast.success('Dosya başarıyla yüklendi!')
    }

    reader.readAsDataURL(file)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    handleFileUpload(e.dataTransfer.files)
  }, [handleFileUpload])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const removeFile = (id: string) => {
    const savedFiles = JSON.parse(localStorage.getItem('sharedFiles') || '[]')
    const filtered = savedFiles.filter((f: SharedFile) => f.id !== id)
    localStorage.setItem('sharedFiles', JSON.stringify(filtered))
    setFiles(prev => prev.filter(f => f.id !== id))
    toast.info('Dosya silindi')
  }

  const copyShareCode = (id: string) => {
    navigator.clipboard.writeText(id)
    setCopiedId(id)
    toast.success('Kod kopyalandı!')
    setTimeout(() => setCopiedId(null), 2000)
  }

  const downloadFile = (file: SharedFile) => {
    const link = document.createElement('a')
    link.href = file.data
    link.download = file.name
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    toast.success('İndirme başladı!')
  }

  const findFileByCode = () => {
    const savedFiles = JSON.parse(localStorage.getItem('sharedFiles') || '[]')
    const found = savedFiles.find((f: SharedFile) => f.id === shareCode.toUpperCase())
    
    if (found) {
      setFiles(prev => {
        const exists = prev.find(f => f.id === found.id)
        if (exists) return prev
        return [...prev, found]
      })
      toast.success('Dosya bulundu!')
      setShareCode('')
    } else {
      toast.error('Dosya bulunamadı!')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
              <Share2 className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold text-slate-800">Dosya Gönder</h1>
          </div>
          <div className="flex items-center gap-3 text-slate-500">
            <Smartphone className="w-5 h-5" />
            <Tablet className="w-5 h-5" />
            <Laptop className="w-5 h-5" />
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8">
        {/* Upload Area */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              className={`
                border-2 border-dashed rounded-2xl p-12 text-center transition-all cursor-pointer
                ${isDragging 
                  ? 'border-blue-500 bg-blue-50' 
                  : 'border-slate-300 hover:border-blue-400 hover:bg-slate-50'
                }
              `}
            >
              <input
                type="file"
                onChange={(e) => handleFileUpload(e.target.files)}
                className="hidden"
                id="file-input"
              />
              <label htmlFor="file-input" className="cursor-pointer block">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-slate-700 mb-2">
                  Dosya Yükle
                </h3>
                <p className="text-slate-500 mb-1">
                  Dosyayı sürükleyin veya tıklayarak seçin
                </p>
                <p className="text-sm text-slate-400">
                  Maksimum 50 MB
                </p>
              </label>
            </div>

            {isUploading && (
              <div className="mt-6">
                <div className="flex justify-between text-sm text-slate-600 mb-2">
                  <span>Yükleniyor...</span>
                  <span>{Math.round(uploadProgress)}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Find File by Code */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-slate-700 mb-4 flex items-center gap-2">
              <Download className="w-5 h-5" />
              Kod ile Dosya Bul
            </h3>
            <div className="flex gap-3">
              <input
                type="text"
                value={shareCode}
                onChange={(e) => setShareCode(e.target.value)}
                placeholder="Örn: ABC12345"
                className="flex-1 px-4 py-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent uppercase"
                maxLength={8}
              />
              <Button 
                onClick={findFileByCode}
                disabled={!shareCode.trim()}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium"
              >
                Bul
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* File List */}
        {files.length > 0 && (
          <div>
            <h3 className="text-lg font-semibold text-slate-700 mb-4">
              Yüklenen Dosyalar ({files.length})
            </h3>
            <div className="space-y-3">
              {files.map((file) => (
                <Card key={file.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center flex-shrink-0">
                        <File className="w-6 h-6 text-blue-600" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-slate-800 truncate">
                          {file.name}
                        </h4>
                        <p className="text-sm text-slate-500">
                          {formatFileSize(file.size)}
                        </p>
                      </div>

                      <div className="flex items-center gap-2">
                        <div className="bg-slate-100 px-3 py-2 rounded-lg flex items-center gap-2">
                          <code className="text-sm font-mono text-slate-700">
                            {file.id}
                          </code>
                          <button
                            onClick={() => copyShareCode(file.id)}
                            className="p-1 hover:bg-white rounded transition-colors"
                            title="Kodu kopyala"
                          >
                            {copiedId === file.id ? (
                              <Check className="w-4 h-4 text-green-600" />
                            ) : (
                              <Copy className="w-4 h-4 text-slate-500" />
                            )}
                          </button>
                        </div>

                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => downloadFile(file)}
                          className="rounded-lg"
                          title="İndir"
                        >
                          <Download className="w-4 h-4" />
                        </Button>

                        <Button
                          variant="outline"
                          size="icon"
                          onClick={() => removeFile(file.id)}
                          className="rounded-lg hover:bg-red-50 hover:text-red-600 hover:border-red-200"
                          title="Sil"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {files.length === 0 && !isUploading && (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <File className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-600 mb-2">
              Henüz dosya yok
            </h3>
            <p className="text-slate-500">
              Dosya yükleyin veya bir kod girerek dosya bulun
            </p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 mt-12">
        <div className="max-w-4xl mx-auto px-4 py-6 text-center text-slate-500 text-sm">
          Cihazlar arası kolay dosya paylaşımı
        </div>
      </footer>
    </div>
  )
}

export default App
